str<-("Count the number of characters") 
result <- nchar(str) 
print(result) 
library(stringr) 
# Calculate length of string      
str_length(str)